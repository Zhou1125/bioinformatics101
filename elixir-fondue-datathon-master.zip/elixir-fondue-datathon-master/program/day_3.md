<img src="images/logo_elixir.png" width="100">

# Day 3 - Monday, 28 June 2021, 10:00 - 13:00 (CEST)

### 10:00 - 10:10 : Welcome & introduction
*Martijn van Kaauwen (WUR, Wageningen) / Matthijs Brouwer (WUR, Wageningen)*

---

### 10:10 - ... : Evalution submitting own data to EVA, ENA and BioSamples
##### (_experts EVA/ENA/BioSamples_)
- Discussion [issues](../../../issues) encountered in the last week
- Opportunity to ask questions

---

### Closing day 3
*Martijn van Kaauwen (WUR, Wageningen) / Matthijs Brouwer (WUR, Wageningen)*
* Discussion / evaluation
* Closing

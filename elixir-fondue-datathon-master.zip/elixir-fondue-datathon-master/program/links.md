# Links


## Workshops for databases:

* European Nucleotide Archive: 
  - https://www.ebi.ac.uk/ena/browser/home
  - https://www.ebi.ac.uk/training/online/courses/ena-quick-tour/

* BIOsamples: 
  - https://www.ebi.ac.uk/biosamples/
  - https://www.ebi.ac.uk/training/online/courses/biosamples-quick-tour/


* European Variation Archive: 
  - https://www.ebi.ac.uk/eva/
  - https://www.ebi.ac.uk/training/online/courses/eva-quick-tour/







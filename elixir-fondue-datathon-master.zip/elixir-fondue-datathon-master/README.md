# ELIXIR FONDUE Datathon 
<img align="right" src="program/images/logo_elixir.png" width="100"/>

### Tuesday 15, Monday 21 and Monday 28 June 2021
Workshop on data submission to EBI
* Introduction Elixir Fondue
* Workshop on submission to 

  - BioSamples
  - European Nucleotide Archive (ENA)
  - European Variation Archive (EVA)

See the full [program](program/) for more details.

### Registration
You can [subscribe](https://forms.gle/uSA4kMX5GnG4L9E46) to this workship until **Thursday 10 June 2021**  (extended to monday 14 June 17.00 hours CET)

<a href="https://forms.gle/uSA4kMX5GnG4L9E46" alt="subscribe" title="subscribe"><img src="program/images/subscribe.png" width="150"/></a>

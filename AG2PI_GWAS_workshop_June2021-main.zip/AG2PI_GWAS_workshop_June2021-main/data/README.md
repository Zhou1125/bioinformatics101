example data for tutorial
